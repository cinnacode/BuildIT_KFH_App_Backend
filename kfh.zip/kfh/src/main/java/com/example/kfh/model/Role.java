package com.example.kfh.model;

public enum Role {
    DEVELOPER,
    SUPER_ADMIN,
    TESTER,
    BUSINESS
}
